"use client"

import { useState } from "react"
import { Heart, Brain, Activity, Loader2 } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface PredictionData {
  age: number
  sex: number
  cp: number
  trestbps: number
  chol: number
  fbs: number
  restecg: number
  thalach: number
  exang: number
  oldpeak: number
  slope: number
  ca: number
  thal: number
}

interface PredictionResult {
  prediction?: string
  message?: string
  Prediction_Probability_Percentage?: number
  error?: string
}

export default function PredictionPage() {
  const [formData, setFormData] = useState<PredictionData>({
    age: 50,
    sex: 1,
    cp: 0,
    trestbps: 120,
    chol: 200,
    fbs: 0,
    restecg: 0,
    thalach: 150,
    exang: 0,
    oldpeak: 0,
    slope: 1,
    ca: 0,
    thal: 2
  })

  const [aiResult, setAiResult] = useState<PredictionResult | null>(null)
  const [mlResult, setMlResult] = useState<PredictionResult | null>(null)
  const [loading, setLoading] = useState({ ai: false, ml: false })

  const handleInputChange = (field: keyof PredictionData, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      [field]: typeof value === 'string' ? parseFloat(value) || 0 : value
    }))
  }

  const predictWithAI = async () => {
    setLoading(prev => ({ ...prev, ai: true }))
    try {
      const response = await fetch('/api/predict-ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      })
      const result = await response.json()
      setAiResult(result)
    } catch (error) {
      setAiResult({ error: 'Failed to get AI prediction' })
    } finally {
      setLoading(prev => ({ ...prev, ai: false }))
    }
  }

  const predictWithML = async () => {
    setLoading(prev => ({ ...prev, ml: true }))
    try {
      const response = await fetch('/api/predict-ml', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      })
      const result = await response.json()
      setMlResult(result)
    } catch (error) {
      setMlResult({ error: 'Failed to get ML prediction' })
    } finally {
      setLoading(prev => ({ ...prev, ml: false }))
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-red-50 to-rose-50 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Heart className="h-10 w-10 text-red-600" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent">
              Heart Attack Risk Prediction
            </h1>
          </div>
          <p className="text-lg text-gray-600">
            Enter your health parameters to get AI-powered and ML-based risk assessments
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Form */}
          <Card className="bg-white/70 backdrop-blur-sm border-white/20 shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl text-red-600">Health Parameters</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    value={formData.age}
                    onChange={(e) => handleInputChange('age', e.target.value)}
                    min="1"
                    max="120"
                  />
                </div>
                <div>
                  <Label htmlFor="sex">Sex</Label>
                  <Select value={formData.sex.toString()} onValueChange={(value) => handleInputChange('sex', parseInt(value))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">Male</SelectItem>
                      <SelectItem value="0">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="cp">Chest Pain Type</Label>
                  <Select value={formData.cp.toString()} onValueChange={(value) => handleInputChange('cp', parseInt(value))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0">Typical Angina</SelectItem>
                      <SelectItem value="1">Atypical Angina</SelectItem>
                      <SelectItem value="2">Non-Anginal Pain</SelectItem>
                      <SelectItem value="3">Asymptomatic</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="trestbps">Resting Blood Pressure</Label>
                  <Input
                    id="trestbps"
                    type="number"
                    value={formData.trestbps}
                    onChange={(e) => handleInputChange('trestbps', e.target.value)}
                    min="80"
                    max="200"
                  />
                </div>
                <div>
                  <Label htmlFor="chol">Cholesterol (mg/dl)</Label>
                  <Input
                    id="chol"
                    type="number"
                    value={formData.chol}
                    onChange={(e) => handleInputChange('chol', e.target.value)}
                    min="100"
                    max="600"
                  />
                </div>
                <div>
                  <Label htmlFor="fbs">Fasting Blood Sugar {'>'} 120 mg/dl</Label>
                  <Select value={formData.fbs.toString()} onValueChange={(value) => handleInputChange('fbs', parseInt(value))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0">No</SelectItem>
                      <SelectItem value="1">Yes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="restecg">Resting ECG</Label>
                  <Select value={formData.restecg.toString()} onValueChange={(value) => handleInputChange('restecg', parseInt(value))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0">Normal</SelectItem>
                      <SelectItem value="1">ST-T Wave Abnormality</SelectItem>
                      <SelectItem value="2">Left Ventricular Hypertrophy</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="thalach">Max Heart Rate Achieved</Label>
                  <Input
                    id="thalach"
                    type="number"
                    value={formData.thalach}
                    onChange={(e) => handleInputChange('thalach', e.target.value)}
                    min="60"
                    max="220"
                  />
                </div>
                <div>
                  <Label htmlFor="exang">Exercise Induced Angina</Label>
                  <Select value={formData.exang.toString()} onValueChange={(value) => handleInputChange('exang', parseInt(value))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0">No</SelectItem>
                      <SelectItem value="1">Yes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="oldpeak">ST Depression</Label>
                  <Input
                    id="oldpeak"
                    type="number"
                    step="0.1"
                    value={formData.oldpeak}
                    onChange={(e) => handleInputChange('oldpeak', e.target.value)}
                    min="0"
                    max="10"
                  />
                </div>
                <div>
                  <Label htmlFor="slope">Slope of Peak Exercise ST</Label>
                  <Select value={formData.slope.toString()} onValueChange={(value) => handleInputChange('slope', parseInt(value))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0">Downsloping</SelectItem>
                      <SelectItem value="1">Flat</SelectItem>
                      <SelectItem value="2">Upsloping</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="ca">Number of Major Vessels</Label>
                  <Select value={formData.ca.toString()} onValueChange={(value) => handleInputChange('ca', parseInt(value))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0">0</SelectItem>
                      <SelectItem value="1">1</SelectItem>
                      <SelectItem value="2">2</SelectItem>
                      <SelectItem value="3">3</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="thal">Thalassemia</Label>
                  <Select value={formData.thal.toString()} onValueChange={(value) => handleInputChange('thal', parseInt(value))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">Fixed Defect</SelectItem>
                      <SelectItem value="2">Normal</SelectItem>
                      <SelectItem value="3">Reversible Defect</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <Button 
                  onClick={predictWithAI} 
                  disabled={loading.ai}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  {loading.ai ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Brain className="mr-2 h-4 w-4" />}
                  AI Analysis
                </Button>
                <Button 
                  onClick={predictWithML} 
                  disabled={loading.ml}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  {loading.ml ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Activity className="mr-2 h-4 w-4" />}
                  ML Prediction
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Results */}
          <Card className="bg-white/70 backdrop-blur-sm border-white/20 shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl text-red-600">Prediction Results</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="ai" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="ai">AI Analysis</TabsTrigger>
                  <TabsTrigger value="ml">ML Prediction</TabsTrigger>
                </TabsList>
                
                <TabsContent value="ai" className="space-y-4">
                  {aiResult ? (
                    <div>
                      {aiResult.error ? (
                        <Alert variant="destructive">
                          <AlertDescription>{aiResult.error}</AlertDescription>
                        </Alert>
                      ) : (
                        <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                          <h3 className="font-semibold text-blue-800 mb-2">AI Analysis Result</h3>
                          <p className="text-blue-700 whitespace-pre-wrap">{aiResult.prediction}</p>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-center text-gray-500 py-8">
                      Click "AI Analysis" to get detailed insights about your heart health risk factors.
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="ml" className="space-y-4">
                  {mlResult ? (
                    <div>
                      {mlResult.error ? (
                        <Alert variant="destructive">
                          <AlertDescription>{mlResult.error}</AlertDescription>
                        </Alert>
                      ) : (
                        <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                          <h3 className="font-semibold text-green-800 mb-2">ML Prediction Result</h3>
                          <p className="text-green-700 mb-2">{mlResult.message}</p>
                          {mlResult.Prediction_Probability_Percentage && (
                            <div className="mt-4">
                              <div className="flex justify-between text-sm text-green-600 mb-1">
                                <span>Risk Probability</span>
                                <span>{mlResult.Prediction_Probability_Percentage.toFixed(2)}%</span>
                              </div>
                              <div className="w-full bg-green-200 rounded-full h-2">
                                <div 
                                  className="bg-green-600 h-2 rounded-full transition-all duration-500"
                                  style={{ width: `${mlResult.Prediction_Probability_Percentage}%` }}
                                ></div>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-center text-gray-500 py-8">
                      Click "ML Prediction" to get a probability-based risk assessment.
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
