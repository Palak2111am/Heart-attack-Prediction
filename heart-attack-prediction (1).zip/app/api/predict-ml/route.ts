import { NextRequest, NextResponse } from 'next/server'

interface PredictionRequest {
  age: number
  sex: number
  cp: number
  trestbps: number
  chol: number
  fbs: number
  restecg: number
  thalach: number
  exang: number
  oldpeak: number
  slope: number
  ca: number
  thal: number
}

export async function POST(request: NextRequest) {
  try {
    const data: PredictionRequest = await request.json()
    
    // Mock ML prediction - replace with actual FastAPI call
    // Simple risk calculation based on key factors
    let riskScore = 0
    
    // Age factor
    if (data.age > 65) riskScore += 30
    else if (data.age > 55) riskScore += 20
    else if (data.age > 45) riskScore += 10
    
    // Cholesterol factor
    if (data.chol > 240) riskScore += 25
    else if (data.chol > 200) riskScore += 15
    
    // Blood pressure factor
    if (data.trestbps > 140) riskScore += 20
    else if (data.trestbps > 120) riskScore += 10
    
    // Exercise factors
    if (data.exang === 1) riskScore += 15
    if (data.thalach < 150) riskScore += 10
    
    // Other factors
    if (data.fbs === 1) riskScore += 10
    if (data.oldpeak > 2) riskScore += 15
    if (data.ca > 0) riskScore += data.ca * 10
    
    // Cap at 100%
    const probability = Math.min(riskScore, 100)
    
    const mockResponse = {
      message: `The probability of the person having a heart attack is ${probability.toFixed(2)}%.`,
      Prediction_Probability_Percentage: probability
    }

    return NextResponse.json(mockResponse)
  } catch (error) {
    console.error('ML Prediction Error:', error)
    return NextResponse.json(
      { error: 'Failed to process ML prediction request' },
      { status: 500 }
    )
  }
}
