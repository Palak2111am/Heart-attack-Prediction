import { NextRequest, NextResponse } from 'next/server'

interface PredictionRequest {
  age: number
  sex: number
  cp: number
  trestbps: number
  chol: number
  fbs: number
  restecg: number
  thalach: number
  exang: number
  oldpeak: number
  slope: number
  ca: number
  thal: number
}

export async function POST(request: NextRequest) {
  try {
    const data: PredictionRequest = await request.json()
    
    // Mock AI response - replace with actual FastAPI call
    const mockResponse = {
      prediction: `Based on the provided health parameters, here's an analysis of cardiovascular risk factors:

Age Factor: At ${data.age} years old, age is ${data.age > 55 ? 'a significant' : 'a moderate'} risk factor for heart disease.

Cholesterol Level: With a cholesterol level of ${data.chol} mg/dl, this is ${data.chol > 240 ? 'high and concerning' : data.chol > 200 ? 'borderline high' : 'within normal range'}.

Blood Pressure: Resting blood pressure of ${data.trestbps} mmHg is ${data.trestbps > 140 ? 'elevated' : data.trestbps > 120 ? 'slightly elevated' : 'normal'}.

Exercise Capacity: Maximum heart rate of ${data.thalach} suggests ${data.thalach < 150 ? 'reduced' : 'good'} exercise tolerance.

Additional Risk Factors: ${data.exang === 1 ? 'Exercise-induced angina is present, which increases risk.' : 'No exercise-induced angina reported.'} ${data.fbs === 1 ? 'Elevated fasting blood sugar is a concern.' : ''}

This analysis is for educational purposes only and should not replace professional medical consultation.`
    }

    return NextResponse.json(mockResponse)
  } catch (error) {
    console.error('AI Prediction Error:', error)
    return NextResponse.json(
      { error: 'Failed to process AI prediction request' },
      { status: 500 }
    )
  }
}
